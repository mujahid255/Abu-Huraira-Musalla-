import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, Mail, MapPin } from "lucide-react";
import Image from "next/image";

export default function AbuHurairaMusalla() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Hero Section */}
      <section className="bg-[url('/hero-image.jpg')] bg-cover bg-center text-white py-32 px-6 text-center relative">
        <div className="absolute top-8 left-1/2 transform -translate-x-1/2">
          <Image
            src="/abu-huraira-logo.png"
            alt="Abu Huraira Logo"
            width={120}
            height={120}
            className="mx-auto"
          />
        </div>
        <h1 className="text-4xl md:text-6xl font-bold mb-4 mt-36">Abu Huraira Musalla</h1>
        <p className="text-xl md:text-2xl mb-6">Building Tomorrow's Leaders</p>
        <Button className="bg-green-600 hover:bg-green-700 text-white text-lg">Donate Now</Button>
      </section>

      {/* About Section */}
      <section className="py-16 px-6 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4 text-center">About Us</h2>
        <p className="text-lg text-center">
          Abu Huraira Musalla is a welcoming space for prayer, learning, and community. We're dedicated to nurturing youth leadership and providing spiritual growth for all.
        </p>
      </section>

      {/* Prayer Times (Placeholder) */}
      <section className="bg-gray-100 py-16 px-6">
        <h2 className="text-3xl font-semibold text-center mb-8">Prayer Times</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
          {['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map((name) => (
            <Card key={name}>
              <CardContent className="p-4">
                <p className="text-lg font-medium">{name}</p>
                <p className="text-sm text-gray-600">00:00 AM</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Donate Section */}
      <section className="py-16 px-6 text-center bg-green-50">
        <h2 className="text-3xl font-semibold mb-4">Support the Musalla</h2>
        <p className="mb-6 text-lg">Your donations help us serve the community and build a better future.</p>
        <Button className="bg-green-600 hover:bg-green-700 text-white text-lg">Contribute Today</Button>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-6 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4 text-center">Contact Us</h2>
        <div className="flex flex-col gap-4 text-center text-lg">
          <p className="flex items-center justify-center gap-2"><MapPin className="w-5 h-5" /> 123 Community Dr, Your City</p>
          <p className="flex items-center justify-center gap-2"><Mail className="w-5 h-5" /> info@abuhuraira.org</p>
          <p className="flex items-center justify-center gap-2"><Clock className="w-5 h-5" /> Open: 5:00 AM – 10:00 PM daily</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 text-center">
        <p>&copy; {new Date().getFullYear()} Abu Huraira Musalla. All rights reserved.</p>
      </footer>
    </div>
  );
}
